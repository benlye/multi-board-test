#ifdef STM32WBxx
#include "stm32wbxx_hal_ipcc.c"
#endif
